const { app } = require('@azure/functions');
const { EmailClient } = require("@azure/communication-email");

app.http('SendContactEmail', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);

        try {
            const body = await request.json();
            const { name, email, phone, message } = body;

            const connectionString = process.env.COMMUNICATION_SERVICES_CONNECTION_STRING;
            if (!connectionString) {
                return { status: 500, body: "Email connection string is not configured." };
            }
            
            const emailClient = new EmailClient(connectionString);

            // Using the Azure Managed Domain sender address.
            const senderAddress = process.env.SENDER_EMAIL_ADDRESS;

            const emailMessage = {
                senderAddress: senderAddress,
                content: {
                    subject: `New Website Lead: ${name}`,
                    plainText: `Name: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nMessage:\n${message}`,
                    html: `
                        <h3>New Contact Form Submission</h3>
                        <p><strong>Name:</strong> ${name}</p>
                        <p><strong>Email:</strong> ${email}</p>
                        <p><strong>Phone:</strong> ${phone}</p>
                        <p><strong>Message:</strong><br>${message.replace(/\\n/g, '<br>')}</p>
                    `
                },
                recipients: {
                    to: [{ address: "aeis_india@yahoo.co.in" }]
                }
            };

            const poller = await emailClient.beginSend(emailMessage);
            const result = await poller.pollUntilDone();

            if (result.status === "Succeeded") {
                return { status: 200, jsonBody: { success: true, message: "Email sent successfully" } };
            } else {
                return { status: 500, jsonBody: { success: false, message: "Failed to send email" } };
            }
            
        } catch (error) {
            context.log.error(error);
            return { status: 500, jsonBody: { success: false, message: error.message } };
        }
    }
});
